<header class="main-header">
      <div class="page-breadcrumb">
        <span id="breadcrumb1">관리자</span><span>›</span>
        <span class="current" id="breadcrumb2">관리자 관리</span>
      </div>
      <div class="header-right">
        <span class="header-time" id="headerTime"></span>
        <a class="btn-icon-header" href="/" title="사이트 보기" target="_blank">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          <span>사이트 보기</span>
        </a>
      </div>
    </header>